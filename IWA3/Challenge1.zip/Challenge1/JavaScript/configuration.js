// configuration.js

const company = 'ACME Inc.'
const year = 2022

export { company }
export { year }